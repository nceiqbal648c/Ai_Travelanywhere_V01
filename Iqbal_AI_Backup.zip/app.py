from flask import Flask, render_template, request, jsonify

# templates ফোল্ডার ছাড়াই বর্তমান ডিরেক্টরি থেকে ফাইল লোড হবে
app = Flask(__name__, template_folder='.')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/download', methods=['POST'])
def download():
    data = request.json
    url = data.get('url')
    print(f"Downloading: {url}")
    return jsonify({"status": "success", "message": "Download Started"})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
